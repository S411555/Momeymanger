MONEY MASTER — REAL LIFE SIMULATOR
===================================

RUN IN VS CODE
1. Extract MoneyMaster_RealLife.zip.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. Right-click and choose "Open with Live Server" (if installed),
   or double-click index.html to open it in your browser.

PAGES INCLUDED
- Dashboard: balance, savings, spending and recent activity
- Budget planner: create and check a practice budget
- Grocery store: purchase realistic everyday items
- Life challenges: make decisions in practical situations
- Savings goals: create a goal and deposit practice money
- Reports: review activity and learning progress

DESIGN
- Professional, realistic dashboard design
- Pakistani rupee practice amounts
- No photographs or depictions of people or animals
- Icons and CSS-only visual elements

IMPORTANT
This is an educational simulation. It uses fictional practice money only.
It does not connect to banks or process real payments.
Progress is saved in this browser using local storage.
